import React from "react";
import { icons } from "../icons/Icons";

function ClientList(props) {
	return (
		<table className="table">
			<thead>
				<tr>
					<th scope="col">Name</th>
					<th scope="col">Email</th>
					<th scope="col">Phone</th>
					<th scope="col"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td scope="row">Tony Stark</td>
					<td>ironman@gmail.com</td>
					<td>9988776655</td>
					<td>
						<button className="btn btn-danger btn-sm">{icons.trash}</button>
					</td>
				</tr>
				<tr>
					<td scope="row">Peter Parker</td>
					<td>spideman@gmail.com</td>
					<td>9876543221</td>
					<td>
						<button className="btn btn-danger btn-sm">{icons.trash}</button>
					</td>
				</tr>
				<tr>
					<td scope="row">Buppy Leheree</td>
					<td>mere.to.l.lag.gye@gmail.com</td>
					<td>9876543231</td>
					<td>
						<button className="btn btn-danger btn-sm">{icons.trash}</button>
					</td>
				</tr>
			</tbody>
		</table>
	);
}

export default ClientList;
