import React from "react";

function ClientModal(props) {
	return (
		<div className="modal fade" tabIndex={-1} id="clientModal">
			<div className="modal-dialog">
				<div className="modal-content">
					<div className="modal-header">
						<h5 className="modal-title">Add Client</h5>
						<button
							type="button"
							className="btn-close"
							data-bs-dismiss="modal"
							aria-label="Close"
						/>
					</div>
					<div className="modal-body">
						<form>
							<div className="mb-3">
								<label htmlFor="name" className="form-label">
									Name
								</label>
								<input
									type="text"
									className="form-control"
									id="exampleInputPassword1"
								/>
							</div>
							<div className="mb-3">
								<label htmlFor="email" className="form-label">
									Email address
								</label>
								<input
									type="email"
									className="form-control"
									id="exampleInputEmail1"
									aria-describedby="emailHelp"
								/>
								<div id="emailHelp" className="form-text"></div>
							</div>
							<div className="mb-3">
								<label htmlFor="name" className="form-label">
									Phone
								</label>
								<input
									type="text"
									className="form-control"
									id="exampleInputPassword1"
								/>
							</div>

							<button type="submit" className="btn btn-primary">
								Submit
							</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	);
}

export default ClientModal;
