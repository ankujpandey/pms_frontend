import React from "react";
import { Link } from "react-router-dom";

function ProjetsCard(props) {
	return (
		<div className="col-md-6">
			<div className="card">
				<div className="card-body">
					<div className="d-flex justify-content-between align-items-center">
						<h5 className="card-title">Project Name</h5>
						<Link to="/project">
							<button type="button" class="btn btn-light">
								View
							</button>
						</Link>
					</div>
					<div className="d-flex align-items-center">
						<p className="text-muted mt-2 me-1 mb-0">Status: </p>
						<p className="card-text mt-2 fw-bold mb-0">Pending</p>
					</div>
				</div>
			</div>
		</div>
	);
}

export default ProjetsCard;
