import React from "react";

export const icons = {
	trash: <i class="bi bi-trash-fill" />,
	list: <i class="bi bi-list-task" />,
	client: <i class="bi bi-person-fill" />,
	clientId: <i class="bi bi-person-badge-fill" />,
	mail: <i class="bi bi-envelope-fill" />,
	phone: <i class="bi bi-telephone-fill" />,
};
