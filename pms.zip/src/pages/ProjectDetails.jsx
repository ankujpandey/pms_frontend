import React from "react";
import { icons } from "../icons/Icons";
import { Link } from "react-router-dom";

function ProjectDetails(props) {
	return (
		<div className="py-5">
			<div className="card container">
				<div className="card-body">
					<div class="d-grid gap-2 d-md-flex justify-content-md-end">
						<Link to="/">
							<button type="button" class="btn btn-light mt-4 px-5">
								Back
							</button>
						</Link>
					</div>

					<h5 className="card-title mt-4 fs-2">e-Commerce Website</h5>
					<p className="card-subtitle mb-2 text-muted">This is a description</p>

					<h6 className="card-text mt-5 fs-4">Project Status</h6>
					<p className="card-subtitle mb-2 text-muted">In Progress</p>

					<div className="mt-5">
						Client Information
						<div className="card mt-2">
							<ul className="list-group list-group-flush">
								<li className="list-group-item">
									{icons.clientId} Peter Parker
								</li>
								<li className="list-group-item">
									{icons.mail} spiderman@gmail.com
								</li>
								<li className="list-group-item">{icons.phone} 999-888-7777</li>
							</ul>
						</div>
					</div>

					<h5 className="card-title fs-2 mt-5">Updated Project Details</h5>

					<div>
						<div className="mb-3">
							<label htmlFor="exampleFormControlInput1" className="form-label">
								Name
							</label>
							<input
								type="text"
								className="form-control"
								id="exampleFormControlInput1"
								placeholder="e-Commerce Website"
							/>
						</div>
						<div className="mb-3">
							<label
								htmlFor="exampleFormControlTextarea1"
								className="form-label">
								Description
							</label>
							<textarea
								className="form-control"
								id="exampleFormControlTextarea1"
								placeholder="This is a Description"
							/>
						</div>

						<div className="mb-3">
							<label htmlfor="description" className="form-label">
								Client
							</label>
							<select className="form-select">
								<option selected>Not Started</option>
								<option value={1}>Started</option>
								<option value={2}>Pending</option>
								<option value={3}>Completed</option>
							</select>
						</div>

						<button type="submit" className="btn btn-warning">
							Submit
						</button>
					</div>
					<div class="d-grid gap-2 d-md-flex justify-content-md-end">
						<button type="button" class="btn btn-danger">
							{icons.trash} Delete Project
						</button>
					</div>
				</div>
			</div>
		</div>
	);
}

export default ProjectDetails;
